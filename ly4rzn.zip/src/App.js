function MyButton() {
  return (
    <button>
      I'm a button
    </button>
  );
}

export default function MyApp() {
  return (
    <div>
      <h1>Kauã Portel Ferraresso</h1>
      <p>Tenho 16 anos;</p>
      <p>Estudo na Etec Polivalente em Americana (SP), cursnado Desenvolvimento de Sistemas;</p> 
      <p>Nasci na cidade de Campinas (SP), mas moro na cidade de Sumaré (SP); </p>
      <p>Gosto de esportes, músicas, livros, filmes, séries,carros, motos, dentre outras coisas;</p>
    </div>
  );
}
